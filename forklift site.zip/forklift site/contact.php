<?php
// Handle form submission when the form is posted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $department = htmlspecialchars($_POST['department']);
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $wms_version = htmlspecialchars($_POST['wms_version']);
    $message = htmlspecialchars($_POST['message']);

    // Prepare email data (for Gmail open)
    $to = "support@wmspro.com"; // Email address
    $subject = urlencode("New Contact Form Submission from $name");
    $body = urlencode("Department: $department\nName: $name\nEmail: $email\nWMS Version: $wms_version\nMessage: \n$message");

    // Construct the mailto URL for Gmail
    $mailto_url = "mailto:support@wmspro.com?subject=$subject&body=$body";

    // Redirect to the mailto link (this will open the user's email client)
    echo "<script>window.location.href = '$mailto_url';</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | WMS Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
    <style>
        .contact-section {
            background: #f8f9fa;
            padding: 50px 0;
        }
        .contact-info {
            background: #ffffff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .icon {
            font-size: 24px;
            color: #0d6efd;
            margin-right: 10px;
        }
        /* Navbar Styling */
        .navbar {
            margin-bottom: 50px;
        }
        /* Vanta Animation Styling */
        #animation-container {
            width: 100%;
            height: 400px;
            margin-top: 50px;
        }
    </style>
</head>
<body>
  <!-- Bootstrap Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">WMS Pro Solutions</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
              data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
              aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="bi bi-house-door-fill"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="place_order.php">
              <i class="bi bi-cart-fill"></i> Place Order
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="daily_activity.php">
              <i class="bi bi-graph-up"></i> Daily Activity
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">
              <i class="bi bi-info-circle-fill"></i> About
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="contact.php">
              <i class="bi bi-envelope-fill"></i> Contact
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    <!-- Contact Section -->
    <section class="contact-section">
        <div class="container">
            <h2 class="text-center mb-5">Contact US</h2>
            
            <div class="row">
                <!-- Contact Information -->
                <div class="col-lg-6 mb-4">
                    <div class="contact-info">
                        <h4 class="mb-4">Get in Touch</h4>
                        <div class="mb-4">
                            <i class="bi bi-map icon"></i>
                            <h5>Headquarters</h5>
                            <p>WMS Pro Solutions<br>
                            123 Logistics Parkway<br>
                            Colombo<br>
                            Sri Lanka.</p>
                        </div>

                        <div class="mb-4">
                            <i class="bi bi-phone icon"></i>
                            <h5>24/7 Support</h5>
                            <p>+94 (91) 223-4589<br>
                            +94 (91) 967-7761</p>
                        </div>

                        <div class="mb-4">
                            <i class="bi bi-envelope icon"></i>
                            <h5>Email</h5>
                            <p>Support: <a href="mailto:support@wmspro.com">support@wmspro.com</a><br>
                            Sales: <a href="mailto:sales@wmspro.com">sales@wmspro.com</a></p>
                        </div>

                        <div class="social-links">
                            <h5>Follow Us</h5>
                            <a href="#" class="btn btn-outline-primary btn-sm me-2">
                                <i class="bi bi-linkedin"></i>
                            </a>
                            <a href="#" class="btn btn-outline-primary btn-sm me-2">
                                <i class="bi bi-twitter"></i>
                            </a>
                            <a href="#" class="btn btn-outline-primary btn-sm">
                                <i class="bi bi-facebook"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Contact Form -->
                <div class="col-lg-6">
                    <div class="contact-info">
                        <h4 class="mb-4">Quick Support Form</h4>
                        <form action="contact.php" method="POST">
                            <div class="mb-3">
                                <label class="form-label">Department</label>
                                <select class="form-select" name="department" required>
                                    <option value="">Select Department</option>
                                    <option value="sales">Sales Inquiry</option>
                                    <option value="support">Technical Support</option>
                                    <option value="implementation">System Implementation</option>
                                </select>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label">Name</label>
                                    <input type="text" class="form-control" name="name" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" required>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Message</label>
                                <textarea class="form-control" rows="5" name="message" placeholder="Describe your issue or inquiry..." required></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bi bi-paperplane-fill me-2"></i>Send Message
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Additional Info -->
            <div class="row mt-5">
                <div class="col-12 text-center">
                    <h5>Emergency Support</h5>
                    <p>For critical system outages, call our 24/7 hotline: +94 (777) 967-1234</p>
                    <div class="alert alert-warning">
                        <strong>Standard Support Hours:</strong> Mon-Fri 8:00 AM - 5:00 PM<br>
                        <strong>Response Time:</strong> 1 hour for priority cases, 24 hours for standard inquiries
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
