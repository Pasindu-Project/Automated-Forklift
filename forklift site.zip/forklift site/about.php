<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>About | WMS Pro</title>
  
  <!-- Bootstrap CSS -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <!-- Bootstrap Icons -->
  <link
    rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css"
  />
  
  <style>
    body {
      background: linear-gradient(135deg, #74ebd5, #9face6);
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
      color: #333;
    }
    /* Content Container */
    .content {
      max-width: 800px;
      margin: 100px auto 50px;
      padding: 20px 30px;
      background-color: #fff;
      border-radius: 10px;
      box-shadow: 0 8px 15px rgba(0, 0, 0, 0.1);
      text-align: justify;
    }
    .content h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #4CAF50;
    }
    .content p {
      line-height: 1.8;
      font-size: 1.1em;
      margin-bottom: 20px;
    }
    .content ul {
      margin: 10px 0 20px 20px;
      padding: 0;
      list-style-type: disc;
    }
    .content ul li {
      line-height: 1.6;
      font-size: 1.1em;
    }
    /* Footer */
    #footer {
      text-align: center;
      margin-top: 30px;
      font-size: 1em;
      color: #555;
      padding-bottom: 20px;
    }
  </style>
</head>
<body>
  <!-- Bootstrap Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">WMS Pro Solutions</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
        data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
        aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
  
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="bi bi-house-door-fill"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="place_order.php">
              <i class="bi bi-cart-fill"></i> Place Order
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="daily_activity.php">
              <i class="bi bi-graph-up"></i> Daily Activity
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="about.php">
              <i class="bi bi-info-circle-fill"></i> About
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">
              <i class="bi bi-envelope-fill"></i> Contact
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  
  <!-- Content Section -->
  <div class="content">
    <h2>About the Warehouse System</h2>
    <p>
      Welcome to the Warehouse Management System. This system is designed to help automate and streamline the process of managing items in a warehouse.
    </p>
    <p>
      The system uses a combination of RFID technology and color recognition to track and manage items. The autonomous vehicle in the warehouse is equipped with sensors that can detect the color of boxes and determine the optimal rack to store the item.
    </p>
    <p>
      The system provides a web interface where users can place orders, track daily activity, and manage the inventory. Orders are placed by specifying the item name, color, and desired action (store or retrieve).
    </p>
    <p>
      <strong>Key Features:</strong>
      <ul>
        <li>Real-time tracking of items in the warehouse</li>
        <li>Color-based item storage and retrieval</li>
        <li>Automatic updates in the system based on RFID readings</li>
        <li>User-friendly web interface</li>
      </ul>
    </p>
    <p>
      We aim to simplify warehouse management and increase efficiency through automation.
    </p>
  </div>
  
  <!-- Footer -->
  <div id="footer">
    &copy; 2025 Warehouse Management System. All rights reserved.
  </div>
  
  <!-- Bootstrap JS Bundle (includes Popper) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
