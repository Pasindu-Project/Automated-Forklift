<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firebase_url = "https://warehouse-35f88-default-rtdb.firebaseio.com/config.json";
    $firebase_auth = "AIzaSyC9Ns57Yhxll5DgPdBir7QqN2NcIG4ysbI";

    $type = $_POST['type'] ?? ''; // 'items' or 'colors'
    $value = $_POST['value'] ?? ''; // New item or color

    if (empty($type) || empty($value)) {
        echo json_encode(['success' => false, 'message' => 'Type or value missing']);
        exit;
    }

    // Fetch current config
    $config_url = $firebase_url . "?auth=" . $firebase_auth;
    $current_config = json_decode(file_get_contents($config_url), true);
    $updated_list = $current_config[$type] ?? [];

    // Add the new value if not already present
    if (!in_array($value, $updated_list)) {
        $updated_list[] = $value;

        // Update Firebase
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://warehouse-35f88-default-rtdb.firebaseio.com/config/$type.json?auth=" . $firebase_auth);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($updated_list));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        $response = curl_exec($ch);
        curl_close($ch);

        echo json_encode(['success' => true, 'message' => ucfirst($type) . " updated successfully"]);
    } else {
        echo json_encode(['success' => false, 'message' => ucfirst($type) . " already exists"]);
    }
}
?>
