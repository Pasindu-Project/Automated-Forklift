<?php
session_start();

// Firebase Realtime Database URL
$firebaseUrl = "https://warehouse-35f88-default-rtdb.firebaseio.com/.json";

// Function to fetch data from Firebase
function getFirebaseData($url) {
    $response = file_get_contents($url);
    if ($response === FALSE) {
        return null;
    }
    return json_decode($response, true);
}

// Fetch data from Firebase
$data = getFirebaseData($firebaseUrl);
if (!$data) {
    die(json_encode(["error" => "Error fetching data from Firebase."]));
}

// Extract detected color and capitalize first letter
$detectedColor = isset($data['color']['detected']) ? ucfirst($data['color']['detected']) : null;

// Ensure detected color is valid
if (empty($detectedColor) || $detectedColor === "Null") {
    $detectedColor = null;
}

// Update detected colors in session for table update only if a valid color is detected
if ($detectedColor) {
    if (!isset($_SESSION['detectedColors'])) {
        $_SESSION['detectedColors'] = [];
    }
    if (!in_array($detectedColor, $_SESSION['detectedColors'])) {
        $_SESSION['detectedColors'][] = $detectedColor;
    }
}

// Store detected colors in session for place_order.php (new feature)
if (!isset($_SESSION['availableColors'])) {
    $_SESSION['availableColors'] = [];
}

// If tableRows is empty, reset availableColors; otherwise, add if new
if (empty($_SESSION['tableRows'])) {
    $_SESSION['availableColors'] = [];
} else {
    if ($detectedColor && !in_array($detectedColor, $_SESSION['availableColors'])) {
        $_SESSION['availableColors'][] = $detectedColor;
    }
}

// Alternatively, ensure availableColors gets updated if valid
if ($detectedColor && !in_array($detectedColor, $_SESSION['availableColors'])) {
    $_SESSION['availableColors'][] = $detectedColor;
}

// Function to get shelf details dynamically based on the detected color
function getShelfDetails($color, $data) {
    $shelfKey = ucfirst($color) . "Shelf"; // e.g., "RedShelf", "GreenShelf", etc.
    if (isset($data[$shelfKey])) {
        $shelf = $data[$shelfKey];
        return [
            'firstFloor'  => isset($shelf['firstFloor']) && $shelf['firstFloor'] ? 'Available' : 'Taken',
            'secondFloor' => isset($shelf['secondFloor']) && $shelf['secondFloor'] ? 'Available' : 'Taken'
        ];
    }
    return ['firstFloor' => 'Unknown', 'secondFloor' => 'Unknown'];
}

// Initialize session table rows if not set
if (!isset($_SESSION['tableRows'])) {
    $_SESSION['tableRows'] = [];
}

// Function to update shelf data in the session table
function updateShelfData($detectedColor, $data) {
    if (!$detectedColor) return; // Only update if we have a valid color

    $colorExists = false;
    foreach ($_SESSION['tableRows'] as &$row) {
        if ($row['color'] === $detectedColor) {
            $shelfDetails = getShelfDetails($detectedColor, $data);
            $row['shelf'] = "First Floor: " . $shelfDetails['firstFloor'] . "<br>Second Floor: " . $shelfDetails['secondFloor'];
            $colorExists = true;
            break;
        }
    }
    if (!$colorExists) {
        $shelfDetails = getShelfDetails($detectedColor, $data);
        $_SESSION['tableRows'][] = [
            'item'  => count($_SESSION['tableRows']) + 1,
            'color' => $detectedColor,
            'shelf' => "First Floor: " . $shelfDetails['firstFloor'] . "<br>Second Floor: " . $shelfDetails['secondFloor']
        ];
    }
}

// Update the detected color in the session table if valid
updateShelfData($detectedColor, $data);

// Handle AJAX requests for table rows
if (isset($_GET['fetch'])) {
    echo json_encode($_SESSION['tableRows']);
    exit;
}

// Handle AJAX requests for available colors (new feature)
if (isset($_GET['fetch_colors'])) {
    echo json_encode($_SESSION['availableColors']);
    exit;
}

// Reset session data when requested
if (isset($_GET['reset'])) {
    $_SESSION['tableRows'] = [];
    echo json_encode(["status" => "success"]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Home | WMS Pro</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" />
  <style>
    body {
      background: #fff;
      color: #333;
    }
    .table-container {
      margin-top: 80px;
    }
    .reset-btn {
      font-size: 16px;
    }
    .table thead {
      background-color: #f8f9fa;
    }
    .table td, .table th {
      vertical-align: middle;
    }
  </style>
</head>
<body>
  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">WMS Pro Solutions</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
              data-bs-target="#navbarNav" aria-controls="navbarNav" 
              aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="bi bi-house-door-fill"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="place_order.php">
              <i class="bi bi-cart-fill"></i> Place Order
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="daily_activity.php">
              <i class="bi bi-graph-up"></i> Daily Activity
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">
              <i class="bi bi-info-circle-fill"></i> About
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">
              <i class="bi bi-envelope-fill"></i> Contact
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Main Container -->
  <div class="container table-container">
    <h2 class="text-center text-primary mb-4">Live Firebase Detected Colors</h2>

    <div class="text-center mb-3">
      <button class="btn btn-danger reset-btn" onclick="resetData()">
        <i class="bi bi-arrow-counterclockwise"></i> Reset Data
      </button>
    </div>

    <div class="table-responsive">
      <table class="table table-bordered table-hover shadow-sm">
        <thead class="table-light">
          <tr>
            <th>Item</th>
            <th>Color</th>
            <th>Shelf Status</th>
          </tr>
        </thead>
        <tbody id="colorTableBody">
          <?php if (isset($_SESSION['tableRows'])): ?>
            <?php foreach ($_SESSION['tableRows'] as $row): ?>
              <tr>
                <td><?php echo htmlspecialchars($row['item']); ?></td>
                <td><?php echo htmlspecialchars($row['color']); ?></td>
                <td><?php echo $row['shelf']; ?></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Bootstrap JS Bundle (includes Popper) -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script>
    // Function to fetch table data
    function fetchData() {
      fetch("index.php?fetch=1")
        .then(response => response.json())
        .then(data => {
          let tableBody = document.getElementById("colorTableBody");
          tableBody.innerHTML = ""; // Clear existing rows

          data.forEach(row => {
            let tr = document.createElement("tr");
            tr.innerHTML = `
              <td>${row.item}</td>
              <td>${row.color}</td>
              <td>${row.shelf}</td>
            `;
            tableBody.appendChild(tr);
          });
        })
        .catch(error => console.error("Error fetching data:", error));
    }

    // Function to reset data
    function resetData() {
      fetch("index.php?reset=1")
        .then(response => response.json())
        .then(data => {
          if (data.status === "success") {
            document.getElementById("colorTableBody").innerHTML = "";
          }
        })
        .catch(error => console.error("Reset error:", error));
    }

    // Optionally, function to fetch available colors (for use on place_order.php or elsewhere)
    function fetchAvailableColors() {
      fetch("index.php?fetch_colors=1")
        .then(response => response.json())
        .then(data => {
          console.log("Available Colors:", data);
          // Use the available colors as needed
        })
        .catch(error => console.error("Error fetching available colors:", error));
    }

    // Auto-refresh every 3 seconds
    setInterval(fetchData, 3000);
    // Fetch data on page load
    fetchData();
  </script>
</body>
</html>
