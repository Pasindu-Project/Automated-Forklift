<?php
session_start();

// Set timezone to Asia/Colombo
date_default_timezone_set("Asia/Colombo");

// Firebase Database URL
$firebaseBaseUrl = "https://warehouse-35f88-default-rtdb.firebaseio.com";

// Retrieve form data
$color = $_POST['color'] ?? null;
$floor = $_POST['floor'] ?? null;
$action = $_POST['action'] ?? null;

if ($color && $floor && $action) {
    // Step 1: Fetch existing orders to determine the next item number
    $ordersUrl = "$firebaseBaseUrl/orders.json";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $ordersUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $orders = json_decode($response, true);
    $nextOrderId = is_array($orders) ? "item_" . (count($orders) + 1) : "item_1"; // Assign next available item number

    // Step 2: Prepare the order data with Colombo timezone timestamp
    $timestamp = date('Y-m-d H:i:s'); // This now uses Asia/Colombo time
    $orderData = json_encode([
        'action'         => $action,
        'placed_color'   => $color,
        'selected_floor' => $floor,
        'timestamp'      => $timestamp
    ]);

    // Step 3: Store the new order under the sequential "item_X" key
    $orderUrl = "$firebaseBaseUrl/orders/$nextOrderId.json";
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $orderUrl);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $orderData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $putResponse = curl_exec($ch);
    curl_close($ch);

    // Step 4: Update Firebase `/color/placed_color` and `/color/selected_floor`
    $colorUpdateUrl = "$firebaseBaseUrl/color.json";
    $colorUpdateData = json_encode([
        "placed_color"   => $color,
        "selected_floor" => $floor
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $colorUpdateUrl);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PATCH"); // Use PATCH to update only these fields
    curl_setopt($ch, CURLOPT_POSTFIELDS, $colorUpdateData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    $patchResponse = curl_exec($ch);
    curl_close($ch);

    // Redirect back with success flag
    header("Location: place_order.php?success=1");
    exit;
} else {
    echo "Invalid data!";
}
?>
