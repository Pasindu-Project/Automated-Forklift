<?php
/********************************
 * 1. Firebase Configuration
 ********************************/
$firebaseUrl = "https://warehouse-35f88-default-rtdb.firebaseio.com";

/********************************
 * 2. Fetch Data from Firebase
 ********************************/
function fetchFromFirebase($path) {
    global $firebaseUrl;
    $url = $firebaseUrl . $path . ".json";

    // Initialize cURL
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    // Decode JSON into PHP array
    return json_decode($response, true);
}

// Fetch orders data from Firebase at the "/orders" node
$orders = fetchFromFirebase("/orders");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Daily Activity</title>
  
  <!-- Bootstrap CSS -->
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  
  <!-- Bootstrap Icons -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
  
  <style>
    body {
      background: #f8f9fa;
    }
    /* Add spacing to account for fixed navbar */
    .content-wrapper {
      margin-top: 80px;
    }
  </style>
</head>

<body>
  <!-- Bootstrap Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">WMS Pro Solutions</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
              data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" 
              aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
  
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php">
              <i class="bi bi-house-door-fill"></i> Home
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="place_order.php">
              <i class="bi bi-cart-fill"></i> Place Order
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" href="daily_activity.php">
              <i class="bi bi-graph-up"></i> Daily Activity
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="about.php">
              <i class="bi bi-info-circle-fill"></i> About
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="contact.php">
              <i class="bi bi-envelope-fill"></i> Contact
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  
  <!-- Page Content -->
  <div class="container content-wrapper">
    <h2 class="mb-4">Daily Activity - Orders</h2>
    <table class="table table-bordered table-striped">
      <thead class="table-dark">
        <tr>
          <th>Order ID</th>
          <th>Placed Color</th>
          <th>Selected Floor</th>
          <th>Timestamp</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Check if we got any data
        if ($orders && is_array($orders)) {
            // Each key => value in $orders is one unique order
            foreach ($orders as $orderId => $orderData) {
                // The keys "placed_color", "selected_floor", and "timestamp" 
                // should match what was stored in place_order.php
                $placedColor   = isset($orderData['placed_color'])   ? $orderData['placed_color']   : 'N/A';
                $selectedFloor = isset($orderData['selected_floor']) ? $orderData['selected_floor'] : 'N/A';
                $timestamp     = isset($orderData['timestamp'])      ? $orderData['timestamp']      : 'N/A';

                echo "<tr>";
                echo "<td>" . htmlspecialchars($orderId) . "</td>";
                echo "<td>" . htmlspecialchars($placedColor) . "</td>";
                echo "<td>" . htmlspecialchars($selectedFloor) . "</td>";
                echo "<td>" . htmlspecialchars($timestamp) . "</td>";
                echo "</tr>";
            }
        } else {
            // If no data, show a single row
            echo "<tr><td colspan='4' class='text-center'>No orders found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
  
  <!-- Bootstrap JS Bundle (includes Popper) -->
  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js">
  </script>
</body>
</html>
