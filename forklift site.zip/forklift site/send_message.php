<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';  // Adjust path if needed

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Validate form data
    if (empty($name) || empty($email) || empty($message)) {
        echo "All fields are required!";
    } else {
        // Send the email using PHPMailer
        $mail = new PHPMailer(true);

        try {
            // Set mailer to use SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';  // SMTP server (using Gmail as an example)
            $mail->SMTPAuth = true;
            $mail->Username = 'your_email@gmail.com'; // Your Gmail address
            $mail->Password = 'your_email_password';  // Your Gmail password (use an App Password if 2FA is enabled)
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Set sender and recipient details
            $mail->setFrom($email, $name);  // The user’s email will be used as the sender
            $mail->addAddress('youremail@example.com');  // Replace with your email address

            // Set email format to HTML (optional)
            $mail->isHTML(false);

            // Email subject and body
            $mail->Subject = 'New Contact Us Message from ' . $name;
            $mail->Body    = "Name: $name\nEmail: $email\nMessage: \n$message";

            // Send email
            $mail->send();
            echo "<script>alert('Your message has been sent successfully. Thank you!'); window.location.href = 'contact.php';</script>";
        } catch (Exception $e) {
            echo "There was an error sending your message. Please try again later. Mailer Error: {$mail->ErrorInfo}";
        }
    }
}
?>
